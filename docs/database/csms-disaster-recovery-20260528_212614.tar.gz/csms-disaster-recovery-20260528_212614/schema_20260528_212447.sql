--
-- PostgreSQL database dump
--

\restrict KUHq6CIkdqxQ8qoW57udEslACDO8LYa6ERIhXV04hu1yBRUZkaxIqBvVs46NmHE

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: audit; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA audit;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

--
-- Name: audit_log; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log (
    id bigint NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
PARTITION BY RANGE (created_at);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: audit; Owner: -
--

CREATE SEQUENCE audit.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: audit; Owner: -
--

ALTER SEQUENCE audit.audit_log_id_seq OWNED BY audit.audit_log.id;


SET default_table_access_method = heap;

--
-- Name: audit_log_2025_11; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2025_11 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2025_12; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2025_12 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_01; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_01 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_02; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_02 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_03; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_03 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_04; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_04 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_05; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_05 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_06; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_06 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_07; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_07 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_08; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_08 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_09; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_09 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_10; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_10 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_11; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_11 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2026_12; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2026_12 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2027_01; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2027_01 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2027_02; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2027_02 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2027_03; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2027_03 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2027_04; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2027_04 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: audit_log_2027_05; Type: TABLE; Schema: audit; Owner: -
--

CREATE TABLE audit.audit_log_2027_05 (
    id bigint DEFAULT nextval('audit.audit_log_id_seq'::regclass) NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text,
    username text,
    user_role text,
    action text NOT NULL,
    event_category text DEFAULT 'SYSTEM'::text NOT NULL,
    severity text DEFAULT 'INFO'::text NOT NULL,
    entity_type text DEFAULT 'SYSTEM'::text NOT NULL,
    entity_id text,
    ip_address inet,
    device_info jsonb,
    request_method text,
    request_route text NOT NULL,
    is_authenticated boolean DEFAULT false,
    was_blocked boolean DEFAULT false,
    block_reason text,
    additional_data jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: CadreChangeRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CadreChangeRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "newCadre" text NOT NULL,
    reason text,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "originalCadre" text,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: Complaint; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Complaint" (
    id text NOT NULL,
    "complaintType" text NOT NULL,
    subject text NOT NULL,
    details text NOT NULL,
    "complainantPhoneNumber" text NOT NULL,
    "nextOfKinPhoneNumber" text NOT NULL,
    attachments text[],
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "officerComments" text,
    "internalNotes" text,
    "rejectionReason" text,
    "complainantId" text NOT NULL,
    "assignedOfficerRole" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: ConfirmationRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ConfirmationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "decisionDate" timestamp(3) without time zone,
    "commissionDecisionDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hrrpReviewedById" text,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "commissionLetterKey" text
);


--
-- Name: Employee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Employee" (
    id text NOT NULL,
    "employeeEntityId" text,
    name text NOT NULL,
    gender text NOT NULL,
    "profileImageUrl" text,
    "dateOfBirth" timestamp(3) without time zone,
    "placeOfBirth" text,
    region text,
    "countryOfBirth" text,
    "zanId" text NOT NULL,
    "phoneNumber" text,
    "contactAddress" text,
    "zssfNumber" text,
    "payrollNumber" text,
    cadre text,
    "salaryScale" text,
    ministry text,
    department text,
    "appointmentType" text,
    "contractType" text,
    "recentTitleDate" timestamp(3) without time zone,
    "currentReportingOffice" text,
    "currentWorkplace" text,
    "employmentDate" timestamp(3) without time zone,
    "confirmationDate" timestamp(3) without time zone,
    "retirementDate" timestamp(3) without time zone,
    status text,
    "ardhilHaliUrl" text,
    "confirmationLetterUrl" text,
    "jobContractUrl" text,
    "birthCertificateUrl" text,
    "institutionId" text NOT NULL,
    "dataSource" text DEFAULT 'HRIMS'::text NOT NULL,
    email text
);


--
-- Name: EmployeeCertificate; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."EmployeeCertificate" (
    id text NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    url text,
    "employeeId" text NOT NULL
);


--
-- Name: Institution; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Institution" (
    id text NOT NULL,
    name text NOT NULL,
    email text,
    "phoneNumber" text,
    "voteNumber" text,
    "tinNumber" text,
    "manualEntryEnabled" boolean DEFAULT false NOT NULL,
    "manualEntryEndDate" timestamp(3) without time zone,
    "manualEntryStartDate" timestamp(3) without time zone
);


--
-- Name: LwopRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."LwopRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    duration text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    "startDate" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: MfaToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MfaToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "tokenType" text NOT NULL,
    email text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "ipAddress" text,
    "userAgent" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Notification" (
    id text NOT NULL,
    message text NOT NULL,
    link text,
    "isRead" boolean DEFAULT false NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: PromotionRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PromotionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "proposedCadre" text NOT NULL,
    "promotionType" text NOT NULL,
    "studiedOutsideCountry" boolean,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "commissionDecisionReason" text,
    "finalCadre" text,
    "hrrpReviewedById" text,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: ResignationRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ResignationRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "effectiveDate" timestamp(3) without time zone NOT NULL,
    reason text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: RetirementRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RetirementRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "retirementType" text NOT NULL,
    "illnessDescription" text,
    "proposedDate" timestamp(3) without time zone NOT NULL,
    "delayReason" text,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: SeparationRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SeparationRequest" (
    id text NOT NULL,
    type text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    reason text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: ServiceExtensionRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ServiceExtensionRequest" (
    id text NOT NULL,
    status text NOT NULL,
    "reviewStage" text NOT NULL,
    "currentRetirementDate" timestamp(3) without time zone NOT NULL,
    "requestedExtensionPeriod" text NOT NULL,
    justification text NOT NULL,
    documents text[],
    "rejectionReason" text,
    "employeeId" text NOT NULL,
    "submittedById" text NOT NULL,
    "reviewedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "hrrpReviewedAt" timestamp(3) without time zone,
    "hrrpReviewedById" text,
    "commissionLetterKey" text,
    "commissionDecisionDate" timestamp(3) without time zone,
    "decisionDate" timestamp(3) without time zone
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "sessionToken" text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "deviceInfo" text,
    location text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "lastActivity" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "isSuspicious" boolean DEFAULT false NOT NULL
);


--
-- Name: SystemSettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemSettings" (
    id text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "employeeId" text,
    "institutionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "phoneNumber" text,
    email text,
    "failedPasswordChangeAttempts" integer DEFAULT 0 NOT NULL,
    "isTemporaryPassword" boolean DEFAULT false NOT NULL,
    "lastPasswordChange" timestamp(3) without time zone,
    "mustChangePassword" boolean DEFAULT false NOT NULL,
    "passwordChangeLockoutUntil" timestamp(3) without time zone,
    "passwordHistory" text[] DEFAULT ARRAY[]::text[],
    "temporaryPasswordExpiry" timestamp(3) without time zone,
    "gracePeriodStartedAt" timestamp(3) without time zone,
    "lastExpirationWarningLevel" integer DEFAULT 0,
    "passwordExpiresAt" timestamp(3) without time zone,
    "failedLoginAttempts" integer DEFAULT 0 NOT NULL,
    "isManuallyLocked" boolean DEFAULT false NOT NULL,
    "lockedAt" timestamp(3) without time zone,
    "lockedBy" text,
    "lockoutNotes" text,
    "loginLockedUntil" timestamp(3) without time zone,
    "loginLockoutReason" text,
    "loginLockoutType" text,
    "lastActivity" timestamp(3) without time zone
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: audit_log_2025_11; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2025_11 FOR VALUES FROM ('2025-11-01 00:00:00+00') TO ('2025-12-01 00:00:00+00');


--
-- Name: audit_log_2025_12; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2025_12 FOR VALUES FROM ('2025-12-01 00:00:00+00') TO ('2026-01-01 00:00:00+00');


--
-- Name: audit_log_2026_01; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_01 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-02-01 00:00:00+00');


--
-- Name: audit_log_2026_02; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_02 FOR VALUES FROM ('2026-02-01 00:00:00+00') TO ('2026-03-01 00:00:00+00');


--
-- Name: audit_log_2026_03; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_03 FOR VALUES FROM ('2026-03-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- Name: audit_log_2026_04; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_04 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-05-01 00:00:00+00');


--
-- Name: audit_log_2026_05; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_05 FOR VALUES FROM ('2026-05-01 00:00:00+00') TO ('2026-06-01 00:00:00+00');


--
-- Name: audit_log_2026_06; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_06 FOR VALUES FROM ('2026-06-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- Name: audit_log_2026_07; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_07 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-08-01 00:00:00+00');


--
-- Name: audit_log_2026_08; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_08 FOR VALUES FROM ('2026-08-01 00:00:00+00') TO ('2026-09-01 00:00:00+00');


--
-- Name: audit_log_2026_09; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_09 FOR VALUES FROM ('2026-09-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


--
-- Name: audit_log_2026_10; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_10 FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2026-11-01 00:00:00+00');


--
-- Name: audit_log_2026_11; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_11 FOR VALUES FROM ('2026-11-01 00:00:00+00') TO ('2026-12-01 00:00:00+00');


--
-- Name: audit_log_2026_12; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2026_12 FOR VALUES FROM ('2026-12-01 00:00:00+00') TO ('2027-01-01 00:00:00+00');


--
-- Name: audit_log_2027_01; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2027_01 FOR VALUES FROM ('2027-01-01 00:00:00+00') TO ('2027-02-01 00:00:00+00');


--
-- Name: audit_log_2027_02; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2027_02 FOR VALUES FROM ('2027-02-01 00:00:00+00') TO ('2027-03-01 00:00:00+00');


--
-- Name: audit_log_2027_03; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2027_03 FOR VALUES FROM ('2027-03-01 00:00:00+00') TO ('2027-04-01 00:00:00+00');


--
-- Name: audit_log_2027_04; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2027_04 FOR VALUES FROM ('2027-04-01 00:00:00+00') TO ('2027-05-01 00:00:00+00');


--
-- Name: audit_log_2027_05; Type: TABLE ATTACH; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ATTACH PARTITION audit.audit_log_2027_05 FOR VALUES FROM ('2027-05-01 00:00:00+00') TO ('2027-06-01 00:00:00+00');


--
-- Name: audit_log id; Type: DEFAULT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log ALTER COLUMN id SET DEFAULT nextval('audit.audit_log_id_seq'::regclass);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2025_11 audit_log_2025_11_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2025_11
    ADD CONSTRAINT audit_log_2025_11_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2025_12 audit_log_2025_12_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2025_12
    ADD CONSTRAINT audit_log_2025_12_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_01 audit_log_2026_01_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_01
    ADD CONSTRAINT audit_log_2026_01_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_02 audit_log_2026_02_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_02
    ADD CONSTRAINT audit_log_2026_02_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_03 audit_log_2026_03_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_03
    ADD CONSTRAINT audit_log_2026_03_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_04 audit_log_2026_04_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_04
    ADD CONSTRAINT audit_log_2026_04_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_05 audit_log_2026_05_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_05
    ADD CONSTRAINT audit_log_2026_05_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_06 audit_log_2026_06_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_06
    ADD CONSTRAINT audit_log_2026_06_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_07 audit_log_2026_07_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_07
    ADD CONSTRAINT audit_log_2026_07_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_08 audit_log_2026_08_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_08
    ADD CONSTRAINT audit_log_2026_08_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_09 audit_log_2026_09_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_09
    ADD CONSTRAINT audit_log_2026_09_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_10 audit_log_2026_10_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_10
    ADD CONSTRAINT audit_log_2026_10_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_11 audit_log_2026_11_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_11
    ADD CONSTRAINT audit_log_2026_11_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2026_12 audit_log_2026_12_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2026_12
    ADD CONSTRAINT audit_log_2026_12_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2027_01 audit_log_2027_01_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2027_01
    ADD CONSTRAINT audit_log_2027_01_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2027_02 audit_log_2027_02_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2027_02
    ADD CONSTRAINT audit_log_2027_02_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2027_03 audit_log_2027_03_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2027_03
    ADD CONSTRAINT audit_log_2027_03_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2027_04 audit_log_2027_04_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2027_04
    ADD CONSTRAINT audit_log_2027_04_pkey PRIMARY KEY (id, created_at);


--
-- Name: audit_log_2027_05 audit_log_2027_05_pkey; Type: CONSTRAINT; Schema: audit; Owner: -
--

ALTER TABLE ONLY audit.audit_log_2027_05
    ADD CONSTRAINT audit_log_2027_05_pkey PRIMARY KEY (id, created_at);


--
-- Name: CadreChangeRequest CadreChangeRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_pkey" PRIMARY KEY (id);


--
-- Name: Complaint Complaint_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_pkey" PRIMARY KEY (id);


--
-- Name: ConfirmationRequest ConfirmationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_pkey" PRIMARY KEY (id);


--
-- Name: EmployeeCertificate EmployeeCertificate_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_pkey" PRIMARY KEY (id);


--
-- Name: Employee Employee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_pkey" PRIMARY KEY (id);


--
-- Name: Institution Institution_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Institution"
    ADD CONSTRAINT "Institution_pkey" PRIMARY KEY (id);


--
-- Name: LwopRequest LwopRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_pkey" PRIMARY KEY (id);


--
-- Name: MfaToken MfaToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MfaToken"
    ADD CONSTRAINT "MfaToken_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PromotionRequest PromotionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_pkey" PRIMARY KEY (id);


--
-- Name: ResignationRequest ResignationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_pkey" PRIMARY KEY (id);


--
-- Name: RetirementRequest RetirementRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_pkey" PRIMARY KEY (id);


--
-- Name: SeparationRequest SeparationRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_pkey" PRIMARY KEY (id);


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SystemSettings SystemSettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSettings"
    ADD CONSTRAINT "SystemSettings_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_log_action; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_action ON ONLY audit.audit_log USING btree (action);


--
-- Name: audit_log_2025_11_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_action_idx ON audit.audit_log_2025_11 USING btree (action);


--
-- Name: idx_audit_log_created_at; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_created_at ON ONLY audit.audit_log USING btree (created_at);


--
-- Name: audit_log_2025_11_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_created_at_idx ON audit.audit_log_2025_11 USING btree (created_at);


--
-- Name: idx_audit_log_event_category; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_event_category ON ONLY audit.audit_log USING btree (event_category);


--
-- Name: audit_log_2025_11_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_event_category_idx ON audit.audit_log_2025_11 USING btree (event_category);


--
-- Name: idx_audit_log_event_id; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_event_id ON ONLY audit.audit_log USING btree (event_id);


--
-- Name: audit_log_2025_11_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_event_id_idx ON audit.audit_log_2025_11 USING btree (event_id);


--
-- Name: idx_audit_log_request_route; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_request_route ON ONLY audit.audit_log USING btree (request_route);


--
-- Name: audit_log_2025_11_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_request_route_idx ON audit.audit_log_2025_11 USING btree (request_route);


--
-- Name: idx_audit_log_severity; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_severity ON ONLY audit.audit_log USING btree (severity);


--
-- Name: audit_log_2025_11_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_severity_idx ON audit.audit_log_2025_11 USING btree (severity);


--
-- Name: idx_audit_log_user_id; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX idx_audit_log_user_id ON ONLY audit.audit_log USING btree (user_id);


--
-- Name: audit_log_2025_11_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_11_user_id_idx ON audit.audit_log_2025_11 USING btree (user_id);


--
-- Name: audit_log_2025_12_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_action_idx ON audit.audit_log_2025_12 USING btree (action);


--
-- Name: audit_log_2025_12_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_created_at_idx ON audit.audit_log_2025_12 USING btree (created_at);


--
-- Name: audit_log_2025_12_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_event_category_idx ON audit.audit_log_2025_12 USING btree (event_category);


--
-- Name: audit_log_2025_12_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_event_id_idx ON audit.audit_log_2025_12 USING btree (event_id);


--
-- Name: audit_log_2025_12_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_request_route_idx ON audit.audit_log_2025_12 USING btree (request_route);


--
-- Name: audit_log_2025_12_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_severity_idx ON audit.audit_log_2025_12 USING btree (severity);


--
-- Name: audit_log_2025_12_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2025_12_user_id_idx ON audit.audit_log_2025_12 USING btree (user_id);


--
-- Name: audit_log_2026_01_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_action_idx ON audit.audit_log_2026_01 USING btree (action);


--
-- Name: audit_log_2026_01_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_created_at_idx ON audit.audit_log_2026_01 USING btree (created_at);


--
-- Name: audit_log_2026_01_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_event_category_idx ON audit.audit_log_2026_01 USING btree (event_category);


--
-- Name: audit_log_2026_01_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_event_id_idx ON audit.audit_log_2026_01 USING btree (event_id);


--
-- Name: audit_log_2026_01_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_request_route_idx ON audit.audit_log_2026_01 USING btree (request_route);


--
-- Name: audit_log_2026_01_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_severity_idx ON audit.audit_log_2026_01 USING btree (severity);


--
-- Name: audit_log_2026_01_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_01_user_id_idx ON audit.audit_log_2026_01 USING btree (user_id);


--
-- Name: audit_log_2026_02_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_action_idx ON audit.audit_log_2026_02 USING btree (action);


--
-- Name: audit_log_2026_02_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_created_at_idx ON audit.audit_log_2026_02 USING btree (created_at);


--
-- Name: audit_log_2026_02_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_event_category_idx ON audit.audit_log_2026_02 USING btree (event_category);


--
-- Name: audit_log_2026_02_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_event_id_idx ON audit.audit_log_2026_02 USING btree (event_id);


--
-- Name: audit_log_2026_02_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_request_route_idx ON audit.audit_log_2026_02 USING btree (request_route);


--
-- Name: audit_log_2026_02_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_severity_idx ON audit.audit_log_2026_02 USING btree (severity);


--
-- Name: audit_log_2026_02_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_02_user_id_idx ON audit.audit_log_2026_02 USING btree (user_id);


--
-- Name: audit_log_2026_03_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_action_idx ON audit.audit_log_2026_03 USING btree (action);


--
-- Name: audit_log_2026_03_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_created_at_idx ON audit.audit_log_2026_03 USING btree (created_at);


--
-- Name: audit_log_2026_03_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_event_category_idx ON audit.audit_log_2026_03 USING btree (event_category);


--
-- Name: audit_log_2026_03_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_event_id_idx ON audit.audit_log_2026_03 USING btree (event_id);


--
-- Name: audit_log_2026_03_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_request_route_idx ON audit.audit_log_2026_03 USING btree (request_route);


--
-- Name: audit_log_2026_03_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_severity_idx ON audit.audit_log_2026_03 USING btree (severity);


--
-- Name: audit_log_2026_03_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_03_user_id_idx ON audit.audit_log_2026_03 USING btree (user_id);


--
-- Name: audit_log_2026_04_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_action_idx ON audit.audit_log_2026_04 USING btree (action);


--
-- Name: audit_log_2026_04_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_created_at_idx ON audit.audit_log_2026_04 USING btree (created_at);


--
-- Name: audit_log_2026_04_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_event_category_idx ON audit.audit_log_2026_04 USING btree (event_category);


--
-- Name: audit_log_2026_04_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_event_id_idx ON audit.audit_log_2026_04 USING btree (event_id);


--
-- Name: audit_log_2026_04_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_request_route_idx ON audit.audit_log_2026_04 USING btree (request_route);


--
-- Name: audit_log_2026_04_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_severity_idx ON audit.audit_log_2026_04 USING btree (severity);


--
-- Name: audit_log_2026_04_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_04_user_id_idx ON audit.audit_log_2026_04 USING btree (user_id);


--
-- Name: audit_log_2026_05_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_action_idx ON audit.audit_log_2026_05 USING btree (action);


--
-- Name: audit_log_2026_05_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_created_at_idx ON audit.audit_log_2026_05 USING btree (created_at);


--
-- Name: audit_log_2026_05_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_event_category_idx ON audit.audit_log_2026_05 USING btree (event_category);


--
-- Name: audit_log_2026_05_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_event_id_idx ON audit.audit_log_2026_05 USING btree (event_id);


--
-- Name: audit_log_2026_05_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_request_route_idx ON audit.audit_log_2026_05 USING btree (request_route);


--
-- Name: audit_log_2026_05_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_severity_idx ON audit.audit_log_2026_05 USING btree (severity);


--
-- Name: audit_log_2026_05_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_05_user_id_idx ON audit.audit_log_2026_05 USING btree (user_id);


--
-- Name: audit_log_2026_06_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_action_idx ON audit.audit_log_2026_06 USING btree (action);


--
-- Name: audit_log_2026_06_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_created_at_idx ON audit.audit_log_2026_06 USING btree (created_at);


--
-- Name: audit_log_2026_06_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_event_category_idx ON audit.audit_log_2026_06 USING btree (event_category);


--
-- Name: audit_log_2026_06_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_event_id_idx ON audit.audit_log_2026_06 USING btree (event_id);


--
-- Name: audit_log_2026_06_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_request_route_idx ON audit.audit_log_2026_06 USING btree (request_route);


--
-- Name: audit_log_2026_06_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_severity_idx ON audit.audit_log_2026_06 USING btree (severity);


--
-- Name: audit_log_2026_06_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_06_user_id_idx ON audit.audit_log_2026_06 USING btree (user_id);


--
-- Name: audit_log_2026_07_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_action_idx ON audit.audit_log_2026_07 USING btree (action);


--
-- Name: audit_log_2026_07_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_created_at_idx ON audit.audit_log_2026_07 USING btree (created_at);


--
-- Name: audit_log_2026_07_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_event_category_idx ON audit.audit_log_2026_07 USING btree (event_category);


--
-- Name: audit_log_2026_07_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_event_id_idx ON audit.audit_log_2026_07 USING btree (event_id);


--
-- Name: audit_log_2026_07_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_request_route_idx ON audit.audit_log_2026_07 USING btree (request_route);


--
-- Name: audit_log_2026_07_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_severity_idx ON audit.audit_log_2026_07 USING btree (severity);


--
-- Name: audit_log_2026_07_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_07_user_id_idx ON audit.audit_log_2026_07 USING btree (user_id);


--
-- Name: audit_log_2026_08_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_action_idx ON audit.audit_log_2026_08 USING btree (action);


--
-- Name: audit_log_2026_08_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_created_at_idx ON audit.audit_log_2026_08 USING btree (created_at);


--
-- Name: audit_log_2026_08_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_event_category_idx ON audit.audit_log_2026_08 USING btree (event_category);


--
-- Name: audit_log_2026_08_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_event_id_idx ON audit.audit_log_2026_08 USING btree (event_id);


--
-- Name: audit_log_2026_08_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_request_route_idx ON audit.audit_log_2026_08 USING btree (request_route);


--
-- Name: audit_log_2026_08_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_severity_idx ON audit.audit_log_2026_08 USING btree (severity);


--
-- Name: audit_log_2026_08_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_08_user_id_idx ON audit.audit_log_2026_08 USING btree (user_id);


--
-- Name: audit_log_2026_09_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_action_idx ON audit.audit_log_2026_09 USING btree (action);


--
-- Name: audit_log_2026_09_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_created_at_idx ON audit.audit_log_2026_09 USING btree (created_at);


--
-- Name: audit_log_2026_09_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_event_category_idx ON audit.audit_log_2026_09 USING btree (event_category);


--
-- Name: audit_log_2026_09_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_event_id_idx ON audit.audit_log_2026_09 USING btree (event_id);


--
-- Name: audit_log_2026_09_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_request_route_idx ON audit.audit_log_2026_09 USING btree (request_route);


--
-- Name: audit_log_2026_09_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_severity_idx ON audit.audit_log_2026_09 USING btree (severity);


--
-- Name: audit_log_2026_09_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_09_user_id_idx ON audit.audit_log_2026_09 USING btree (user_id);


--
-- Name: audit_log_2026_10_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_action_idx ON audit.audit_log_2026_10 USING btree (action);


--
-- Name: audit_log_2026_10_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_created_at_idx ON audit.audit_log_2026_10 USING btree (created_at);


--
-- Name: audit_log_2026_10_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_event_category_idx ON audit.audit_log_2026_10 USING btree (event_category);


--
-- Name: audit_log_2026_10_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_event_id_idx ON audit.audit_log_2026_10 USING btree (event_id);


--
-- Name: audit_log_2026_10_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_request_route_idx ON audit.audit_log_2026_10 USING btree (request_route);


--
-- Name: audit_log_2026_10_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_severity_idx ON audit.audit_log_2026_10 USING btree (severity);


--
-- Name: audit_log_2026_10_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_10_user_id_idx ON audit.audit_log_2026_10 USING btree (user_id);


--
-- Name: audit_log_2026_11_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_action_idx ON audit.audit_log_2026_11 USING btree (action);


--
-- Name: audit_log_2026_11_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_created_at_idx ON audit.audit_log_2026_11 USING btree (created_at);


--
-- Name: audit_log_2026_11_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_event_category_idx ON audit.audit_log_2026_11 USING btree (event_category);


--
-- Name: audit_log_2026_11_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_event_id_idx ON audit.audit_log_2026_11 USING btree (event_id);


--
-- Name: audit_log_2026_11_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_request_route_idx ON audit.audit_log_2026_11 USING btree (request_route);


--
-- Name: audit_log_2026_11_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_severity_idx ON audit.audit_log_2026_11 USING btree (severity);


--
-- Name: audit_log_2026_11_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_11_user_id_idx ON audit.audit_log_2026_11 USING btree (user_id);


--
-- Name: audit_log_2026_12_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_action_idx ON audit.audit_log_2026_12 USING btree (action);


--
-- Name: audit_log_2026_12_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_created_at_idx ON audit.audit_log_2026_12 USING btree (created_at);


--
-- Name: audit_log_2026_12_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_event_category_idx ON audit.audit_log_2026_12 USING btree (event_category);


--
-- Name: audit_log_2026_12_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_event_id_idx ON audit.audit_log_2026_12 USING btree (event_id);


--
-- Name: audit_log_2026_12_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_request_route_idx ON audit.audit_log_2026_12 USING btree (request_route);


--
-- Name: audit_log_2026_12_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_severity_idx ON audit.audit_log_2026_12 USING btree (severity);


--
-- Name: audit_log_2026_12_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2026_12_user_id_idx ON audit.audit_log_2026_12 USING btree (user_id);


--
-- Name: audit_log_2027_01_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_action_idx ON audit.audit_log_2027_01 USING btree (action);


--
-- Name: audit_log_2027_01_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_created_at_idx ON audit.audit_log_2027_01 USING btree (created_at);


--
-- Name: audit_log_2027_01_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_event_category_idx ON audit.audit_log_2027_01 USING btree (event_category);


--
-- Name: audit_log_2027_01_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_event_id_idx ON audit.audit_log_2027_01 USING btree (event_id);


--
-- Name: audit_log_2027_01_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_request_route_idx ON audit.audit_log_2027_01 USING btree (request_route);


--
-- Name: audit_log_2027_01_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_severity_idx ON audit.audit_log_2027_01 USING btree (severity);


--
-- Name: audit_log_2027_01_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_01_user_id_idx ON audit.audit_log_2027_01 USING btree (user_id);


--
-- Name: audit_log_2027_02_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_action_idx ON audit.audit_log_2027_02 USING btree (action);


--
-- Name: audit_log_2027_02_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_created_at_idx ON audit.audit_log_2027_02 USING btree (created_at);


--
-- Name: audit_log_2027_02_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_event_category_idx ON audit.audit_log_2027_02 USING btree (event_category);


--
-- Name: audit_log_2027_02_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_event_id_idx ON audit.audit_log_2027_02 USING btree (event_id);


--
-- Name: audit_log_2027_02_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_request_route_idx ON audit.audit_log_2027_02 USING btree (request_route);


--
-- Name: audit_log_2027_02_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_severity_idx ON audit.audit_log_2027_02 USING btree (severity);


--
-- Name: audit_log_2027_02_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_02_user_id_idx ON audit.audit_log_2027_02 USING btree (user_id);


--
-- Name: audit_log_2027_03_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_action_idx ON audit.audit_log_2027_03 USING btree (action);


--
-- Name: audit_log_2027_03_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_created_at_idx ON audit.audit_log_2027_03 USING btree (created_at);


--
-- Name: audit_log_2027_03_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_event_category_idx ON audit.audit_log_2027_03 USING btree (event_category);


--
-- Name: audit_log_2027_03_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_event_id_idx ON audit.audit_log_2027_03 USING btree (event_id);


--
-- Name: audit_log_2027_03_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_request_route_idx ON audit.audit_log_2027_03 USING btree (request_route);


--
-- Name: audit_log_2027_03_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_severity_idx ON audit.audit_log_2027_03 USING btree (severity);


--
-- Name: audit_log_2027_03_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_03_user_id_idx ON audit.audit_log_2027_03 USING btree (user_id);


--
-- Name: audit_log_2027_04_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_action_idx ON audit.audit_log_2027_04 USING btree (action);


--
-- Name: audit_log_2027_04_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_created_at_idx ON audit.audit_log_2027_04 USING btree (created_at);


--
-- Name: audit_log_2027_04_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_event_category_idx ON audit.audit_log_2027_04 USING btree (event_category);


--
-- Name: audit_log_2027_04_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_event_id_idx ON audit.audit_log_2027_04 USING btree (event_id);


--
-- Name: audit_log_2027_04_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_request_route_idx ON audit.audit_log_2027_04 USING btree (request_route);


--
-- Name: audit_log_2027_04_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_severity_idx ON audit.audit_log_2027_04 USING btree (severity);


--
-- Name: audit_log_2027_04_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_04_user_id_idx ON audit.audit_log_2027_04 USING btree (user_id);


--
-- Name: audit_log_2027_05_action_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_action_idx ON audit.audit_log_2027_05 USING btree (action);


--
-- Name: audit_log_2027_05_created_at_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_created_at_idx ON audit.audit_log_2027_05 USING btree (created_at);


--
-- Name: audit_log_2027_05_event_category_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_event_category_idx ON audit.audit_log_2027_05 USING btree (event_category);


--
-- Name: audit_log_2027_05_event_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_event_id_idx ON audit.audit_log_2027_05 USING btree (event_id);


--
-- Name: audit_log_2027_05_request_route_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_request_route_idx ON audit.audit_log_2027_05 USING btree (request_route);


--
-- Name: audit_log_2027_05_severity_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_severity_idx ON audit.audit_log_2027_05 USING btree (severity);


--
-- Name: audit_log_2027_05_user_id_idx; Type: INDEX; Schema: audit; Owner: -
--

CREATE INDEX audit_log_2027_05_user_id_idx ON audit.audit_log_2027_05 USING btree (user_id);


--
-- Name: CadreChangeRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CadreChangeRequest_createdAt_idx" ON public."CadreChangeRequest" USING btree ("createdAt" DESC);


--
-- Name: CadreChangeRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CadreChangeRequest_employeeId_idx" ON public."CadreChangeRequest" USING btree ("employeeId");


--
-- Name: CadreChangeRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CadreChangeRequest_hrrpReviewedById_idx" ON public."CadreChangeRequest" USING btree ("hrrpReviewedById");


--
-- Name: CadreChangeRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CadreChangeRequest_reviewStage_idx" ON public."CadreChangeRequest" USING btree ("reviewStage");


--
-- Name: CadreChangeRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CadreChangeRequest_status_idx" ON public."CadreChangeRequest" USING btree (status);


--
-- Name: Complaint_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Complaint_createdAt_idx" ON public."Complaint" USING btree ("createdAt" DESC);


--
-- Name: Complaint_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Complaint_reviewStage_idx" ON public."Complaint" USING btree ("reviewStage");


--
-- Name: Complaint_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Complaint_status_idx" ON public."Complaint" USING btree (status);


--
-- Name: ConfirmationRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ConfirmationRequest_createdAt_idx" ON public."ConfirmationRequest" USING btree ("createdAt" DESC);


--
-- Name: ConfirmationRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ConfirmationRequest_employeeId_idx" ON public."ConfirmationRequest" USING btree ("employeeId");


--
-- Name: ConfirmationRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ConfirmationRequest_hrrpReviewedById_idx" ON public."ConfirmationRequest" USING btree ("hrrpReviewedById");


--
-- Name: ConfirmationRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ConfirmationRequest_reviewStage_idx" ON public."ConfirmationRequest" USING btree ("reviewStage");


--
-- Name: ConfirmationRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ConfirmationRequest_status_idx" ON public."ConfirmationRequest" USING btree (status);


--
-- Name: Employee_dataSource_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_dataSource_idx" ON public."Employee" USING btree ("dataSource");


--
-- Name: Employee_employmentDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_employmentDate_idx" ON public."Employee" USING btree ("employmentDate" DESC);


--
-- Name: Employee_institutionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_institutionId_idx" ON public."Employee" USING btree ("institutionId");


--
-- Name: Employee_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_name_idx" ON public."Employee" USING btree (name);


--
-- Name: Employee_payrollNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_payrollNumber_idx" ON public."Employee" USING btree ("payrollNumber");


--
-- Name: Employee_status_institutionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Employee_status_institutionId_idx" ON public."Employee" USING btree (status, "institutionId");


--
-- Name: Employee_zanId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Employee_zanId_key" ON public."Employee" USING btree ("zanId");


--
-- Name: Institution_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Institution_name_key" ON public."Institution" USING btree (name);


--
-- Name: Institution_tinNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Institution_tinNumber_key" ON public."Institution" USING btree ("tinNumber");


--
-- Name: LwopRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LwopRequest_createdAt_idx" ON public."LwopRequest" USING btree ("createdAt" DESC);


--
-- Name: LwopRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LwopRequest_employeeId_idx" ON public."LwopRequest" USING btree ("employeeId");


--
-- Name: LwopRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LwopRequest_hrrpReviewedById_idx" ON public."LwopRequest" USING btree ("hrrpReviewedById");


--
-- Name: LwopRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LwopRequest_reviewStage_idx" ON public."LwopRequest" USING btree ("reviewStage");


--
-- Name: LwopRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "LwopRequest_status_idx" ON public."LwopRequest" USING btree (status);


--
-- Name: MfaToken_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MfaToken_expiresAt_idx" ON public."MfaToken" USING btree ("expiresAt");


--
-- Name: MfaToken_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MfaToken_token_idx" ON public."MfaToken" USING btree (token);


--
-- Name: MfaToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "MfaToken_token_key" ON public."MfaToken" USING btree (token);


--
-- Name: MfaToken_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "MfaToken_userId_idx" ON public."MfaToken" USING btree ("userId");


--
-- Name: Notification_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_createdAt_idx" ON public."Notification" USING btree ("createdAt" DESC);


--
-- Name: Notification_isRead_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_isRead_idx" ON public."Notification" USING btree ("isRead");


--
-- Name: Notification_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Notification_userId_idx" ON public."Notification" USING btree ("userId");


--
-- Name: PromotionRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PromotionRequest_createdAt_idx" ON public."PromotionRequest" USING btree ("createdAt" DESC);


--
-- Name: PromotionRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PromotionRequest_employeeId_idx" ON public."PromotionRequest" USING btree ("employeeId");


--
-- Name: PromotionRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PromotionRequest_hrrpReviewedById_idx" ON public."PromotionRequest" USING btree ("hrrpReviewedById");


--
-- Name: PromotionRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PromotionRequest_reviewStage_idx" ON public."PromotionRequest" USING btree ("reviewStage");


--
-- Name: PromotionRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "PromotionRequest_status_idx" ON public."PromotionRequest" USING btree (status);


--
-- Name: ResignationRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ResignationRequest_createdAt_idx" ON public."ResignationRequest" USING btree ("createdAt" DESC);


--
-- Name: ResignationRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ResignationRequest_employeeId_idx" ON public."ResignationRequest" USING btree ("employeeId");


--
-- Name: ResignationRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ResignationRequest_hrrpReviewedById_idx" ON public."ResignationRequest" USING btree ("hrrpReviewedById");


--
-- Name: ResignationRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ResignationRequest_reviewStage_idx" ON public."ResignationRequest" USING btree ("reviewStage");


--
-- Name: ResignationRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ResignationRequest_status_idx" ON public."ResignationRequest" USING btree (status);


--
-- Name: RetirementRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RetirementRequest_createdAt_idx" ON public."RetirementRequest" USING btree ("createdAt" DESC);


--
-- Name: RetirementRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RetirementRequest_employeeId_idx" ON public."RetirementRequest" USING btree ("employeeId");


--
-- Name: RetirementRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RetirementRequest_hrrpReviewedById_idx" ON public."RetirementRequest" USING btree ("hrrpReviewedById");


--
-- Name: RetirementRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RetirementRequest_reviewStage_idx" ON public."RetirementRequest" USING btree ("reviewStage");


--
-- Name: RetirementRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "RetirementRequest_status_idx" ON public."RetirementRequest" USING btree (status);


--
-- Name: SeparationRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeparationRequest_createdAt_idx" ON public."SeparationRequest" USING btree ("createdAt" DESC);


--
-- Name: SeparationRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeparationRequest_employeeId_idx" ON public."SeparationRequest" USING btree ("employeeId");


--
-- Name: SeparationRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeparationRequest_hrrpReviewedById_idx" ON public."SeparationRequest" USING btree ("hrrpReviewedById");


--
-- Name: SeparationRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeparationRequest_reviewStage_idx" ON public."SeparationRequest" USING btree ("reviewStage");


--
-- Name: SeparationRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SeparationRequest_status_idx" ON public."SeparationRequest" USING btree (status);


--
-- Name: ServiceExtensionRequest_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceExtensionRequest_createdAt_idx" ON public."ServiceExtensionRequest" USING btree ("createdAt" DESC);


--
-- Name: ServiceExtensionRequest_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceExtensionRequest_employeeId_idx" ON public."ServiceExtensionRequest" USING btree ("employeeId");


--
-- Name: ServiceExtensionRequest_hrrpReviewedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceExtensionRequest_hrrpReviewedById_idx" ON public."ServiceExtensionRequest" USING btree ("hrrpReviewedById");


--
-- Name: ServiceExtensionRequest_reviewStage_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceExtensionRequest_reviewStage_idx" ON public."ServiceExtensionRequest" USING btree ("reviewStage");


--
-- Name: ServiceExtensionRequest_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ServiceExtensionRequest_status_idx" ON public."ServiceExtensionRequest" USING btree (status);


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_sessionToken_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_sessionToken_idx" ON public."Session" USING btree ("sessionToken");


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: SystemSettings_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "SystemSettings_key_idx" ON public."SystemSettings" USING btree (key);


--
-- Name: SystemSettings_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemSettings_key_key" ON public."SystemSettings" USING btree (key);


--
-- Name: User_employeeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_employeeId_key" ON public."User" USING btree ("employeeId");


--
-- Name: User_institutionId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_institutionId_idx" ON public."User" USING btree ("institutionId");


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: idx_employee_institution_probation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_institution_probation ON public."Employee" USING btree ("institutionId", status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_institution_retirement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_institution_retirement ON public."Employee" USING btree ("institutionId", "retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_probation_overdue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_employee_probation_overdue ON public."Employee" USING btree (status, "employmentDate") WHERE (status <> 'Confirmed'::text);


--
-- Name: idx_employee_retirementDate; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_employee_retirementDate" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: idx_employee_retirementDate_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_employee_retirementDate_range" ON public."Employee" USING btree ("retirementDate") WHERE ("retirementDate" IS NOT NULL);


--
-- Name: audit_log_2025_11_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2025_11_action_idx;


--
-- Name: audit_log_2025_11_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2025_11_created_at_idx;


--
-- Name: audit_log_2025_11_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2025_11_event_category_idx;


--
-- Name: audit_log_2025_11_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2025_11_event_id_idx;


--
-- Name: audit_log_2025_11_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2025_11_pkey;


--
-- Name: audit_log_2025_11_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2025_11_request_route_idx;


--
-- Name: audit_log_2025_11_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2025_11_severity_idx;


--
-- Name: audit_log_2025_11_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2025_11_user_id_idx;


--
-- Name: audit_log_2025_12_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2025_12_action_idx;


--
-- Name: audit_log_2025_12_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2025_12_created_at_idx;


--
-- Name: audit_log_2025_12_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2025_12_event_category_idx;


--
-- Name: audit_log_2025_12_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2025_12_event_id_idx;


--
-- Name: audit_log_2025_12_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2025_12_pkey;


--
-- Name: audit_log_2025_12_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2025_12_request_route_idx;


--
-- Name: audit_log_2025_12_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2025_12_severity_idx;


--
-- Name: audit_log_2025_12_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2025_12_user_id_idx;


--
-- Name: audit_log_2026_01_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_01_action_idx;


--
-- Name: audit_log_2026_01_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_01_created_at_idx;


--
-- Name: audit_log_2026_01_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_01_event_category_idx;


--
-- Name: audit_log_2026_01_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_01_event_id_idx;


--
-- Name: audit_log_2026_01_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_01_pkey;


--
-- Name: audit_log_2026_01_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_01_request_route_idx;


--
-- Name: audit_log_2026_01_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_01_severity_idx;


--
-- Name: audit_log_2026_01_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_01_user_id_idx;


--
-- Name: audit_log_2026_02_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_02_action_idx;


--
-- Name: audit_log_2026_02_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_02_created_at_idx;


--
-- Name: audit_log_2026_02_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_02_event_category_idx;


--
-- Name: audit_log_2026_02_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_02_event_id_idx;


--
-- Name: audit_log_2026_02_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_02_pkey;


--
-- Name: audit_log_2026_02_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_02_request_route_idx;


--
-- Name: audit_log_2026_02_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_02_severity_idx;


--
-- Name: audit_log_2026_02_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_02_user_id_idx;


--
-- Name: audit_log_2026_03_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_03_action_idx;


--
-- Name: audit_log_2026_03_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_03_created_at_idx;


--
-- Name: audit_log_2026_03_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_03_event_category_idx;


--
-- Name: audit_log_2026_03_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_03_event_id_idx;


--
-- Name: audit_log_2026_03_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_03_pkey;


--
-- Name: audit_log_2026_03_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_03_request_route_idx;


--
-- Name: audit_log_2026_03_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_03_severity_idx;


--
-- Name: audit_log_2026_03_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_03_user_id_idx;


--
-- Name: audit_log_2026_04_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_04_action_idx;


--
-- Name: audit_log_2026_04_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_04_created_at_idx;


--
-- Name: audit_log_2026_04_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_04_event_category_idx;


--
-- Name: audit_log_2026_04_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_04_event_id_idx;


--
-- Name: audit_log_2026_04_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_04_pkey;


--
-- Name: audit_log_2026_04_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_04_request_route_idx;


--
-- Name: audit_log_2026_04_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_04_severity_idx;


--
-- Name: audit_log_2026_04_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_04_user_id_idx;


--
-- Name: audit_log_2026_05_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_05_action_idx;


--
-- Name: audit_log_2026_05_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_05_created_at_idx;


--
-- Name: audit_log_2026_05_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_05_event_category_idx;


--
-- Name: audit_log_2026_05_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_05_event_id_idx;


--
-- Name: audit_log_2026_05_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_05_pkey;


--
-- Name: audit_log_2026_05_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_05_request_route_idx;


--
-- Name: audit_log_2026_05_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_05_severity_idx;


--
-- Name: audit_log_2026_05_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_05_user_id_idx;


--
-- Name: audit_log_2026_06_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_06_action_idx;


--
-- Name: audit_log_2026_06_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_06_created_at_idx;


--
-- Name: audit_log_2026_06_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_06_event_category_idx;


--
-- Name: audit_log_2026_06_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_06_event_id_idx;


--
-- Name: audit_log_2026_06_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_06_pkey;


--
-- Name: audit_log_2026_06_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_06_request_route_idx;


--
-- Name: audit_log_2026_06_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_06_severity_idx;


--
-- Name: audit_log_2026_06_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_06_user_id_idx;


--
-- Name: audit_log_2026_07_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_07_action_idx;


--
-- Name: audit_log_2026_07_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_07_created_at_idx;


--
-- Name: audit_log_2026_07_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_07_event_category_idx;


--
-- Name: audit_log_2026_07_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_07_event_id_idx;


--
-- Name: audit_log_2026_07_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_07_pkey;


--
-- Name: audit_log_2026_07_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_07_request_route_idx;


--
-- Name: audit_log_2026_07_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_07_severity_idx;


--
-- Name: audit_log_2026_07_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_07_user_id_idx;


--
-- Name: audit_log_2026_08_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_08_action_idx;


--
-- Name: audit_log_2026_08_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_08_created_at_idx;


--
-- Name: audit_log_2026_08_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_08_event_category_idx;


--
-- Name: audit_log_2026_08_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_08_event_id_idx;


--
-- Name: audit_log_2026_08_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_08_pkey;


--
-- Name: audit_log_2026_08_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_08_request_route_idx;


--
-- Name: audit_log_2026_08_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_08_severity_idx;


--
-- Name: audit_log_2026_08_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_08_user_id_idx;


--
-- Name: audit_log_2026_09_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_09_action_idx;


--
-- Name: audit_log_2026_09_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_09_created_at_idx;


--
-- Name: audit_log_2026_09_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_09_event_category_idx;


--
-- Name: audit_log_2026_09_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_09_event_id_idx;


--
-- Name: audit_log_2026_09_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_09_pkey;


--
-- Name: audit_log_2026_09_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_09_request_route_idx;


--
-- Name: audit_log_2026_09_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_09_severity_idx;


--
-- Name: audit_log_2026_09_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_09_user_id_idx;


--
-- Name: audit_log_2026_10_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_10_action_idx;


--
-- Name: audit_log_2026_10_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_10_created_at_idx;


--
-- Name: audit_log_2026_10_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_10_event_category_idx;


--
-- Name: audit_log_2026_10_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_10_event_id_idx;


--
-- Name: audit_log_2026_10_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_10_pkey;


--
-- Name: audit_log_2026_10_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_10_request_route_idx;


--
-- Name: audit_log_2026_10_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_10_severity_idx;


--
-- Name: audit_log_2026_10_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_10_user_id_idx;


--
-- Name: audit_log_2026_11_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_11_action_idx;


--
-- Name: audit_log_2026_11_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_11_created_at_idx;


--
-- Name: audit_log_2026_11_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_11_event_category_idx;


--
-- Name: audit_log_2026_11_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_11_event_id_idx;


--
-- Name: audit_log_2026_11_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_11_pkey;


--
-- Name: audit_log_2026_11_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_11_request_route_idx;


--
-- Name: audit_log_2026_11_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_11_severity_idx;


--
-- Name: audit_log_2026_11_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_11_user_id_idx;


--
-- Name: audit_log_2026_12_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2026_12_action_idx;


--
-- Name: audit_log_2026_12_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2026_12_created_at_idx;


--
-- Name: audit_log_2026_12_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2026_12_event_category_idx;


--
-- Name: audit_log_2026_12_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2026_12_event_id_idx;


--
-- Name: audit_log_2026_12_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2026_12_pkey;


--
-- Name: audit_log_2026_12_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2026_12_request_route_idx;


--
-- Name: audit_log_2026_12_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2026_12_severity_idx;


--
-- Name: audit_log_2026_12_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2026_12_user_id_idx;


--
-- Name: audit_log_2027_01_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2027_01_action_idx;


--
-- Name: audit_log_2027_01_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2027_01_created_at_idx;


--
-- Name: audit_log_2027_01_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2027_01_event_category_idx;


--
-- Name: audit_log_2027_01_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2027_01_event_id_idx;


--
-- Name: audit_log_2027_01_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2027_01_pkey;


--
-- Name: audit_log_2027_01_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2027_01_request_route_idx;


--
-- Name: audit_log_2027_01_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2027_01_severity_idx;


--
-- Name: audit_log_2027_01_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2027_01_user_id_idx;


--
-- Name: audit_log_2027_02_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2027_02_action_idx;


--
-- Name: audit_log_2027_02_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2027_02_created_at_idx;


--
-- Name: audit_log_2027_02_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2027_02_event_category_idx;


--
-- Name: audit_log_2027_02_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2027_02_event_id_idx;


--
-- Name: audit_log_2027_02_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2027_02_pkey;


--
-- Name: audit_log_2027_02_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2027_02_request_route_idx;


--
-- Name: audit_log_2027_02_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2027_02_severity_idx;


--
-- Name: audit_log_2027_02_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2027_02_user_id_idx;


--
-- Name: audit_log_2027_03_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2027_03_action_idx;


--
-- Name: audit_log_2027_03_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2027_03_created_at_idx;


--
-- Name: audit_log_2027_03_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2027_03_event_category_idx;


--
-- Name: audit_log_2027_03_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2027_03_event_id_idx;


--
-- Name: audit_log_2027_03_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2027_03_pkey;


--
-- Name: audit_log_2027_03_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2027_03_request_route_idx;


--
-- Name: audit_log_2027_03_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2027_03_severity_idx;


--
-- Name: audit_log_2027_03_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2027_03_user_id_idx;


--
-- Name: audit_log_2027_04_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2027_04_action_idx;


--
-- Name: audit_log_2027_04_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2027_04_created_at_idx;


--
-- Name: audit_log_2027_04_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2027_04_event_category_idx;


--
-- Name: audit_log_2027_04_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2027_04_event_id_idx;


--
-- Name: audit_log_2027_04_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2027_04_pkey;


--
-- Name: audit_log_2027_04_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2027_04_request_route_idx;


--
-- Name: audit_log_2027_04_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2027_04_severity_idx;


--
-- Name: audit_log_2027_04_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2027_04_user_id_idx;


--
-- Name: audit_log_2027_05_action_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_action ATTACH PARTITION audit.audit_log_2027_05_action_idx;


--
-- Name: audit_log_2027_05_created_at_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_created_at ATTACH PARTITION audit.audit_log_2027_05_created_at_idx;


--
-- Name: audit_log_2027_05_event_category_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_category ATTACH PARTITION audit.audit_log_2027_05_event_category_idx;


--
-- Name: audit_log_2027_05_event_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_event_id ATTACH PARTITION audit.audit_log_2027_05_event_id_idx;


--
-- Name: audit_log_2027_05_pkey; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.audit_log_pkey ATTACH PARTITION audit.audit_log_2027_05_pkey;


--
-- Name: audit_log_2027_05_request_route_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_request_route ATTACH PARTITION audit.audit_log_2027_05_request_route_idx;


--
-- Name: audit_log_2027_05_severity_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_severity ATTACH PARTITION audit.audit_log_2027_05_severity_idx;


--
-- Name: audit_log_2027_05_user_id_idx; Type: INDEX ATTACH; Schema: audit; Owner: -
--

ALTER INDEX audit.idx_audit_log_user_id ATTACH PARTITION audit.audit_log_2027_05_user_id_idx;


--
-- Name: CadreChangeRequest CadreChangeRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CadreChangeRequest CadreChangeRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CadreChangeRequest CadreChangeRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CadreChangeRequest CadreChangeRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CadreChangeRequest"
    ADD CONSTRAINT "CadreChangeRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_complainantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_complainantId_fkey" FOREIGN KEY ("complainantId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Complaint Complaint_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Complaint"
    ADD CONSTRAINT "Complaint_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConfirmationRequest ConfirmationRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ConfirmationRequest ConfirmationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ConfirmationRequest"
    ADD CONSTRAINT "ConfirmationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: EmployeeCertificate EmployeeCertificate_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."EmployeeCertificate"
    ADD CONSTRAINT "EmployeeCertificate_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Employee Employee_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Employee"
    ADD CONSTRAINT "Employee_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: LwopRequest LwopRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LwopRequest LwopRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: LwopRequest LwopRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."LwopRequest"
    ADD CONSTRAINT "LwopRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: MfaToken MfaToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MfaToken"
    ADD CONSTRAINT "MfaToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Notification Notification_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PromotionRequest PromotionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PromotionRequest PromotionRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromotionRequest PromotionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PromotionRequest PromotionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PromotionRequest"
    ADD CONSTRAINT "PromotionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ResignationRequest ResignationRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResignationRequest ResignationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ResignationRequest ResignationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ResignationRequest"
    ADD CONSTRAINT "ResignationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RetirementRequest RetirementRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RetirementRequest RetirementRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: RetirementRequest RetirementRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RetirementRequest"
    ADD CONSTRAINT "RetirementRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SeparationRequest SeparationRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeparationRequest SeparationRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SeparationRequest SeparationRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SeparationRequest"
    ADD CONSTRAINT "SeparationRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_hrrpReviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_hrrpReviewedById_fkey" FOREIGN KEY ("hrrpReviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_reviewedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_reviewedById_fkey" FOREIGN KEY ("reviewedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: ServiceExtensionRequest ServiceExtensionRequest_submittedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ServiceExtensionRequest"
    ADD CONSTRAINT "ServiceExtensionRequest_submittedById_fkey" FOREIGN KEY ("submittedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_employeeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_employeeId_fkey" FOREIGN KEY ("employeeId") REFERENCES public."Employee"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: User User_institutionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_institutionId_fkey" FOREIGN KEY ("institutionId") REFERENCES public."Institution"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict KUHq6CIkdqxQ8qoW57udEslACDO8LYa6ERIhXV04hu1yBRUZkaxIqBvVs46NmHE

